import bg from './bg.jpg'

import picture from './picture.png'

import confetti from './confetti.gif'

import CakeSVG from './svg/CakeSVG'



export {
    bg,
    picture,
    confetti,
    CakeSVG
}